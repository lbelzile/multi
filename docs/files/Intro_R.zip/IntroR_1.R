
2 + 2


## Installer un paquet depuis le CRAN
## Effectuer cette action une seule fois
install.packages("remotes")
## Charger à chaque session/script
library(remotes)
library(tidyverse) # noter conflits
## Installation depuis Github
## :: pour utiliser une fonction d'un paquet
remotes::install_github("lbelzile/hecmodstat")
## Charger une base de données d'un paquet
data(distraction, package = "hecmodstat")



# Dans RStudio, je vous recommende d'installer le paquet `this.path`
# et de travailler localement relativement à votre dossier
setwd(this.path::here())

## Consulter l'aide
?Normal
??"Normal distribution"



# ceci est un commentaire
a = 1 # ceci est un commentaire mais a=1 est une commande R


2 + 3
pi
2 + 3 * pi
log(2 + 3 * pi)
log(2, base = 10)
log(2, base = 2)
exp(2.435785)



typeof(1:5) # entier, avec 2L
typeof(TRUE) # logique / booléen
typeof(1.234) # numérique
typeof("string") # chaîne de caractères, entre guillemets simples ou doubles

mean(1:5)
mean(c("abc","def"))



facteur <- factor(1:3, # vecteur de valeurs
       levels = 1:4, # valeur des niveaux, par défaut les valeurs uniques
       labels = c("un", "deux", "trois", "quatre") # étiquettes
       )
# classe du vecteur
class(facteur)
# Modifier la catégorie de référence
relevel(facteur, ref = "trois")
# Convertir un vecteur de caractères en facteur et
#  imprimer le décompte de chaque catégorie
table(factor(mpg$drv))



NA_Date_



ls()




## rm(a) # retirer un élément 'a'
## rm(ls()) # retirer la liste de toutes les variables



methods(class = "lm")



a = 3 # Crée un vecteur de taille 1 (scalaire) nommé 'a, qui prend la valeur 3
a # Imprimer la valeur de a
a <- 3 # meme code avec l'opérateur <-, préféré
b <- 5 # Crée une vecteur 'b', qui prend la valeur 5
b - a # Affiche la valeur de b - a
# Stocke la valeur de b / a dans une nouvelle variable 'd'
# et imprimer ce qui est entre parenthèse
(d <- b / a)



# Créer un vecteur x de 10 éléments numériques
x <- c(2, 3, 1, 5, 4, 6, 5, 7, 6, 8)
# Séquence régulière d'entiers
1:10 # entiers de 1 à 10, pas enregistré
seq(1, 10, by = 1)
x # Imprimer valeurs de x
x[3] # Affiche le 3e élément de x
a <- x[3] # Sauvegarde le 3e élément de 'x' dans un objet appelé 'a'
a # Affiche la valeur de a
length(x) # longueur de x, un attribut des vecteurs



salaire <- c(36, 54, 42, 81) # Salaire pour 4 employés
# Pourcentage d'augmentation de salaire pour chaque employé
augmentation <- c(0.02, 0.02, 0.03, 0.05)
salaire_final <- salaire * (1 + augmentation)
salaire_final



z.trans <- matrix(1:9, nrow = 3)
# Remplir plutôt la matrice ligne par ligne
z <- matrix(1:9, nrow = 3, byrow = TRUE)
# Attributs de matrices
dim(z) # dimensions (# lignes, n# colonnes)
ncol(z) # nombre de colonnes
nrow(z) # nombre de lignes
length(z) # nombre d'entrées



z[2,3] # Élément de la ligne 2 et colonne 3
z[,1] # 1e colonne
z[1,] # 1e ligne



z <- matrix(0, nrow = 5, ncol = 2)
# Remplir une matrice 5 par 2 de zéros,
# l'argument 0 est recyclé
# Créer deux vecteurs
amount.dollars <- c(55, 70, 100, 20, 15)
amount.euros <- 0.66 * amount.dollars
# Remplir les 2 colonnes de la matrice avec chacun des vecteurs
z[,1] <- amount.dollars
z[,2] <- amount.euros
z



# Liste avec arguments nommés
liste <- list(a = 1:3, b = letters[1:10])
# Extraire un élément spécifique par son nom
liste$a # premier élément
liste[[2]] # deuxième élément
# Ajuster un modèle linéaire - le résultat est une liste avec des attributs supplémentaires
linmod <- lm(formula = hwy ~ displ, data = mpg)
typeof(linmod)
# Noms des éléments de la liste
names(linmod)

electric <- read.table(file = "Data/electricbill.txt",
                       header = TRUE)
head(electric, n = 5L) # cinq premières lignes
str(electric)
nrow(electric)
ncol(electric)



# Affiche l'element [2,3] (ligne #2 et col #3) de la base de données
electric[2,3]
# Affiche la 1re ligne
electric[1,]
# Affiche la 3e colonne (les 6 premiers éléments seulement)
head(electric[,3])



# 2e colonne (YEAR)
head(electric$YEAR)



# Sauvegarder la 5eme colonne de electric dans l'objet appelé elec5
elec5 <- electric[, 5]
# Affiche le contenu de elec5 (5 premiers elements)
head(elec5, n = 5L)



attach(electric)
head(YEAR)



# Créer une nouvelle variable YEAR2 qui compte les années de YEAR de 1 à 10
YEAR2 <- YEAR - 1990
head(YEAR2)

# Convertir la temperature des Fahrenheit en Celsius
TEMP.CELSIUS <- (TEMP - 32) / 1.8
head(TEMP.CELSIUS)



# Créer une base de données appelé electric qui contient seulement
# les colonnes YEAR, BILL and CONSUMPTION
electric2 <- with(electric,
                  data.frame(YEAR = YEAR,
                             BILL = BILL,
                             CONSUMPTION = CONSUMPTION)
)
head(electric2)

# Modifie une base de données existante et y ajouter la colonne
# TEMP.CELSIUS créée plus haut
electric3 <- data.frame(electric,
                       TEMP.CELSIUS = TEMP.CELSIUS)
head(electric3)


# Installer les paquets - ne faire qu'une fois
# (analogie: acheter un livre)
install.packages(c("knitr", "quarto", "rmarkdown"))
# Charger les paquets dans R
# (prendre le livre dans sa bibliothèque)
library(knitr)

