
# install.packages("MAVE")
# Extraire directement les données Kaggle d'un paquet
data(kc_house_data, package = "MAVE")
maisons <- kc_house_data # renommer pour faciliter l'analyse
str(maisons)
summary(maisons$price)


## -----------------------------
# Variable "price"
par(mfrow = c(1, 2))
prix <- maisons$price # prix
hist(prix / 1e5, # modifier échelle pour clarté des étiquettes
     main = "",
     ylab = "fréquence",
     xlab = "prix (en 100K USD)")
# Boîte à moustache - pas adéquat vu le volume
boxplot(prix  / 1e5,
        horizontal = FALSE,
        main = "", # libellé du titre
        xlab = "prix (en 100K USD)",
        log = "y") #libellé de l'axe des x


## -----------------------------
hist(log(prix, base = 10),
     main = "",
     ylab = "fréquence",
     xlab = "prix (en log 10 USD)")
boxplot(log(prix, base = 10),
        horizontal = FALSE,
        # log = "y" # mettre un axe logarithmique avec données brutes
        main = "", # libellé du titre
        xlab = "prix (en log(10) USD)")


## -----------------------------
# Pourcentage des observations qui excèdent 200K, 300K, 400K
sapply(c(2e5, 3e5, 4e5), function(val){mean(prix > val)})


## -----------------------------
table(maisons$bedrooms)


## -----------------------------
# Bedrooms
par(mfrow = c(2, 2), pch = 20, bty = "l")
plot(I(price / 1e5) ~ bedrooms,
     data = maisons,
     xlab = "nombre de chambres",
     ylab = "prix (en 100K USD)")
plot(log(price, base = 10) ~ bedrooms,
     data = maisons,
     xlab = "nombre de chambres",
     ylab = "prix (en log[10] USD)")
with(maisons |> dplyr::filter(bedrooms < 9),
  plot(x = bedrooms,
       y = price / 1e5,
       xlab = "nombre de chambres",
       ylab = "prix (en 100K USD)"))
with(maisons |> dplyr::filter(bedrooms < 9),
  plot(x = bedrooms,
       y = log(price, base = 10), # base 10 pour interprétabilité
       xlab = "nombre de chambres",
       ylab = expression("prix (en log[10] USD)")))



## -----------------------------
library(ggplot2) # grammaire des graphiques
library(patchwork) # combiner des objets ggplot
theme_set(theme_classic()) # choisir le thème graphique


## -----------------------------
ggplot(data = maisons,
       mapping = aes(x = price / 1e5)) +
  geom_histogram() + # choix de la représentation graphique
  scale_y_continuous(limits = c(0, NA),
                     expand = expansion(mult = c(0, 0.1))) +
  labs(x = "prix (en 100K USD)", # étiquettes des axes, titre, sous-titre, etc.
       y = "décompte")


## -----------------------------
g1 <- ggplot(maisons,
             aes(x = log(price, base = 10))) +
  geom_histogram(binwidth = 0.5) +
  labs(x = "prix (log base 10 USD)",
       y = "décompte",
       caption = "largeur de boîte de 1/2")



## -----------------------------
g1 <- ggplot(maisons,
             aes(y = log(price, base = 10))) +
  geom_boxplot() +
  labs(x = "prix (en log[10] USD)")

g2 <- ggplot(maisons,
             aes(y = log(price, base = 10))) +
  geom_boxplot(fill = "gray",
               color = "black") +
  theme_minimal()
# Combiner des graphiques avec "patchwork"
# g1 + g2 pour côte à côte, g1 / g2 pour haut/bas
g1 + g2


## -----------------------------
maisons |>
  dplyr::mutate(
    floors_fact = factor(floors)) |>
  ggplot(mapping = aes(x = floors_fact,
                       y = prix,
                       color = floors_fact)) +
  geom_boxplot() +
  scale_y_continuous(transform = "log10",
                     labels = scales::dollar_format(
                       scale = .001,
                       accuracy = 1,
                       suffix = "K")) +
  labs(title = "prix (en USD) par nombre d'étages",
       x = "nombre d'étages",
       y = "") +
  theme(legend.position = "none")


## -----------------------------
ggplot(maisons,
                aes(x = bedrooms,
                    y = log(prix, base = 10))) +
  geom_point(alpha = .3) +
  geom_smooth(
  method = "lm",
  se = FALSE,
  color = "red",
  linetype = "dashed") +
  labs(title = "Prix (log base 10 USD) en fonction du nombre de chambres",
       x = "nombre de chambres",
       y = "")


## -----------------------------
maisons |>
  dplyr::mutate(fcondition = factor(
    condition,
    labels = c("mauvaise", "acceptable", "moyen", "bon", "très bon"))
    ) |>
ggplot(aes(x = price,
           y = fcondition)) +
  ggridges::geom_density_ridges() +
  scale_x_continuous(transform = "log10",
                     labels = scales::dollar_format(
                       scale = .001,
                       accuracy = 1,
                       suffix = "K")) +
  labs(title = "Prix selon la condition",
       x = "prix (en USD)",
       y = "condition") +
  theme_classic()

