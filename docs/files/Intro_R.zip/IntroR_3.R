# Fonction pour ajouter deux nombres
add.2.numbers <- function(a, b){
   sum <- a+b
   return(sum)
}
# Appeler une fonction (arguments dans l'ordre si non spécifiés
add.2.numbers(3, 4)


sommediff <- function(a, b){
   somme <- a + b
   diff <- a - b
   # par défaut, le dernier énoncé est retourné si return() est omis
   list("somme" = somme,
        "diff" = diff)
}
sommediff(3, 4)

# Boucle "for"
# Afficher une série de chiffres successifs à l'écran
for (i in seq_len(4)){ # pour 1 à 4
   print(i^2)
}

# Autre exemple
# Afficher une série d'éléments d'un ensemble donné à l'écran
for (w in c("red", "blue", "green")){
   print(w)
}



#' Créer des graphiques pour un employé
#'
#' @param x base de données
#' @param emp identifiant de l'employé que l'on veut analyser
#' @return NULL; des graphiques
sales <- function(x, emp){
   if(sum(x$EmpID == emp) == 0){
      stop("Cet employé n'existe pas.")
   }
   par(mfrow = c(1, 2))
   plot(x = 1:12,
        y = x$nSales[x$EmpID == emp],
        type = 'l',
        xlab = "mois",
        ylab = "nombre de transactions")
   title(paste("nombre de transactions de l'employé", emp, "par mois"))
   plot(x = 1:12,
        y= (x$TotSales/x$nSales)[x$EmpID==emp],
        type = 'l',
        xlab = "mois",
        ylab = "ventes moyenne")
   title("Montant moyen des ventes par mois")
}


##
# Création d'un vecteur qui contient une valeur manquante
x <- c(1, NA, 5.6, -1, 0)

# Retourne des indicateurs de valeurs manquantes TRUE/FALSE
is.na(x)

# Que se passe-t-il lorsque on veut prendre le log d'une valeur NA ?
log(x)


# Retourne des indicateurs logiques de valeurs manquantes "not a number" (NaN)
is.na(x)
is.nan(x)
is.finite(x) # vrai si NA, NaN, ou Inf, -Inf


## Appel de fonction avec valeurs manquantes dans l'argument
mean(x)
mean(x, na.rm = TRUE)


##
sum(is.na(x)) # nombre de valeurs manquantes
x[!is.na(x)]


#' Nombre de valeurs manquantes
#'
#' @param x vecteur
#' @param prop proportion de valeurs manquantes, 0.1 par défaut
#' @return nombre de valeurs manquantes
nb.na <- function(x, prop = 0.1){
  if(mean(is.na(x)) >= prop){
     warning(paste("Proportion de valeurs manquantes supérieure à", propr))
  }
  return(sum(is.na(x)))
}


donnees <- read.table("Data/salesmen.txt", header = TRUE)

# Mettre les données sous la forme d'un cube
# Dimensions: 12 (mois) * 150 (clients) * 4 (variables)
donnees_array <- array(as.matrix(donnees), c(12, 150, 4))

# Données pour le 1er client, 1er mois
donnees_array[1, 1, ]

# Données pour le 1er client
donnees_array[, 1, ]

# Données pour le 1er mois
head(donnees_array[1, , ])

# Nombre de ventes pour tous les employés en janvier (6 premières lignes)
head(donnees_array[1, , c(1, 3)])

# Vente moyenne mensuelle pour le 3e employé
donnees_array[, 3, 4]/donnees_array[, 3, 3]


# Creation d'une liste qui va contenir 5 elements:
# year, succursale, ID, nbre de ventes par mois et total vente par mois
donnees_list <- with(donnees,
                     list(
   year = 2012,
   succ = "Montreal Centre",
   ID = unique(EmpID),
   nb = t(matrix(nSales, nrow = 12)),
   montant = t(matrix(TotSales, nrow = 12))
   ))
names(donnees_list)


# Extraire de la liste le nbre de vente pour tous les employés par mois
# (6 premières lignes)
head(donnees_list$nb)

# Autre facon de faire la même chose...
head(donnees_list[[4]])

# Extraire de la liste le nbre de vente pour tous les mois, premier sujet
donnees_list[[4]][1, ]


# Lignes = mois
# Colonnes = employés
nb_vente <- donnees_array[, , 3]
dim(nb_vente)


# Applique la fonction "mean" à toutes les lignes (donc mois) de la matrice
# Cela donne la moyenne des ventes par mois
apply(nb_vente, 1, mean)

# Même chose, en spécifiant l'option na.rm = TRUE de la fonction mean
apply(nb_vente, 1, mean, na.rm = TRUE)

# Applique la fonction "mean" à toutes les colonnes (donc employés) de la matrice
# Cela donne la moyenne des ventes par employé (6 premières lignes)
head(apply(nb_vente, 2, mean, na.rm = TRUE))

# Valeurs min et max par mois
apply(nb_vente, 1, range, na.rm = TRUE)

# Valeurs min et max par employé pour les 10 premiers employés
apply(nb_vente[, 1:10],
      MARGIN = 2, #dimensions à conserver (ici colonnes)
      FUN = range, # fonction à appliquer
      na.rm = TRUE) # paramètres additionnels à passer à la fonction

fn <- function(i, num = 1:10){
     sum(num^i)
}
sapply(0:5, fn)

