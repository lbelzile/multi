library(dplyr)
donnees <- read.table("Data/salesmen.txt", header = TRUE)

# l'argument de gauche sert de premier argument à la fonction de droite
nrow(donnees)
donnees |> nrow()

# Autre exemple:
x <- c(1, 2, 5, 6)
round(exp(diff(log(x))), 1)

# L'ordre des opérations est plus lisible avec le tuyau
x |>
  log() |>
  diff() |>
  exp() |>
  round(1) # ici, 1 est fourni au 2e argument (digits)


donnees <- tibble::as_tibble(donnees)

# Extrait les obs pour lesquelles EmpID > 1005
donnees |> filter(EmpID > 1005)

# Extrait les obs pour lesquelles nSales <= 10 ET EmpID > 1005
# Tous les énoncés séparés par des virgules doivent être vrais
donnees |> filter(EmpID > 1005,
                  nSales <= 10)

# Extrait les obs pour lesquelles EmpID > 1005 ou nSales <= 10
donnees |> filter(EmpID %in% c(1000, 1005))
# Erreurs fréquentes:
# 1. Mettre un seul signe d'égalité plutôt que ==
# 2. Mettre des énoncés mutuellement exclusifs plutôt qu'utiliser %in%
donnees |> filter(
  EmpID == 1000,
  EmpID == 1005)
# Retourne un tableau vide, puisque les deux énoncés ne peuvent être simultanéments vrais



# Créer un tableau qui contient les colonnes EmpID et Month
donnees |>
  select(EmpID,
         Month)

# Créer un tableau sans les colonnes nSales et TotSales de donnees
donnees |>
  select(-c(nSales, TotSales))

# Créer un tableau qui contient toutes les colonnes entre EmpID et nSales
donnees |>
  select(EmpID:nSales)


donnees |>
  select(contains("Sales"))

donnees |>
  select(starts_with("Emp"))


donnees <- donnees |>
  mutate(ventesMoy = TotSales / nSales,
         EmpID = factor(EmpID))


partie1  <- read.table("Data/sales_part1.txt")
colnames(partie1)
unique(partie1$EmpID)
partie2 <- read.table("Data/sales_part2.txt")
partie3 <- read.table("Data/sales_part3.txt")


# Combiner ensemble les données partie1 et part 2 par ligne
sales_combine <- bind_rows(partie1, partie2)

sales_full <- sales_combine |>
  full_join(y = partie3,
            by = c("EmpID", "Month"))
head(sales_full)
tail(sales_full)

sales_jtgauche <- partie1 |>
  left_join(y = partie3,
            by = c("EmpID", "Month"))
head(sales_jtgauche)
tail(sales_jtgauche)

sales_jtdroite <- partie1 |>
  right_join(y = partie3,
             by = c("EmpID", "Month"))
head(sales_jtdroite)
tail(sales_jtdroite)



# Combinaison group_by + summarize dans `dplyr`
donnees |>
  group_by(EmpID) |> # nom de facteur(s)
  summarize(somme_nSales = sum(nSales, na.rm = TRUE),
            somme_TotSales = sum(TotSales, na.rm = TRUE))

# Calculer la moyenne de toutes les colonnes numériques
donnees |>
  group_by(EmpID) |>
  summarize(across(where(is.numeric), ~ mean(.x, na.rm = TRUE)))


subset(donnees, EmpID == 1000 & Month <= 5)
subset(donnees, EmpID == 1000 & Month <= 5,
       select = c(Month, nSales, TotSales))


# Créer
mat1 <- matrix(1:25, ncol = 5, byrow = TRUE)
mat2 <- matrix(1:15, ncol = 5, byrow = TRUE)

# Combiner des lignes
rbind(mat1, mat2)

# Combiner des colonnes
mat3 <- matrix(1:15, nrow = 5, byrow = TRUE)
cbind(mat1, mat3)


emp_comb <- rbind(partie1, data.frame(partie2, Team="B"))
sales_merge2 <- merge(x = emp_comb,
                      y = partie3,
                      by = c("EmpID", "Month"),
                      all = TRUE)
head(sales_merge2)
tail(sales_merge2)

# Fonction `aggregate` (R de base)
with(donnees,
     aggregate(cbind(nSales, TotSales) ~ EmpID,
               FUN = sum,
               na.rm = TRUE))


