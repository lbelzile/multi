
# Lecture des données
donnees <- read.table("Data/electricbill.txt", header = TRUE) |>
  subset(select = c("BILL","YEAR", "MONTH", "CONSUMPTION"))
BILL <- donnees$BILL
# Quelques opérations usuelles sur les vecteurs
length(BILL) # nombre d'entrées de l'objet
sum(BILL) # somme des éléments
sum(BILL^2) # somme des éléments au carré
mean(BILL) # moyenne
var(BILL) # variance
sd(BILL) # écart-type (racine carrée de la variance)
isTRUE(all.equal(sqrt(var(BILL)), sd(BILL)))
summary(BILL) # résumé
quantile(BILL, probs = 0.25) # 1e quartile
table(donnees$YEAR) # décompte par modalité

summary(donnees)


# Spécifier les valeurs des arguments avec le signe =
x <- MASS::mvrnorm(100, mu = 1, Sigma = 1)

YEAR <- donnees$YEAR
(condition <- YEAR == 1991)

condition <- YEAR > 1995 # plus grand
condition <- YEAR >= 1995 # plus grand ou égal
condition <- YEAR != 1992 # différent de...

# Extrait de la variable YEAR seulement les éléments pour lesquelles la condition est vraie
YEAR[YEAR > 1995]

# Extrait de la variable BILL seulement les éléments correspondant à l'année 1991
donnees$BILL[YEAR == 1991]

# Extrait des données les lignes correspondant à l'année 1991
donnees[YEAR==1991,]

# Extrait des données les observations avec BILL>200
donnees[BILL>200,]


# Dimensions d'une nouvelle base de données qui contient
#  seulement les mois de janvier et de février
# dim(donnees[donnees$MONTH == 'Jan' | donnees$MONTH == 'Feb', ])
sousbd <- donnees[donnees$MONTH %in% c('Jan','Feb'), ]
dim(sousbd)
head(sousbd)

# Seulement les observations avec 100<BILL<200
head(donnees[(BILL > 100) & (BILL < 200), ], nrow = 5L)

# Séquence d'entiers de 5 à 10
5:10
# Séquence de 1 à 10 avec des sauts de 2
seq(from = 1L, to = 10L, by = 2L)

# Sequence de 0 à 10, de longueur 11
seq(0, 10, length = 11)
# par défaut, R assigne les valeurs aux arguments dans l'ordre d'apparation

# Répétition du chiffre 1, 10 fois
rep(1, length.out = 10L)

# Répétition de la séquence 1-2-3, cinq fois
rep(1:3, 5)


# Extrait de BILL les observation (1,3,6)
BILL[c(1,3,6)]

# Extrait les 10 premières observations de BILL
BILL[1:10]

# Extrait les 10 premières lignes de mydata
head(donnees, n = 10)

# Extrait une ligne sur deux de mydata2 pour les colonnes (1,2,4)
donnees[seq(1, nrow(donnees), by = 2), -3]


plot(BILL ~ CONSUMPTION, data = donnees)


plot(BILL ~ CONSUMPTION, # formule sous forme y ~ x
  data = donnees,
  type = "p", # "p" pour point, "l" pour ligne, etc.
  xlab = "Consommation d'électricité (en kw/h) ",
  main =  "Facture en fonction de la consommation d'électricité",
  ylab = "Montant de la facture (en $)",
  pch = 19) # type de point, cercle plein
abline(lm(BILL ~ CONSUMPTION, data = donnees), col = "green")
# abline(h = 6000, col = "green") #ligne horizontale
# abline(v = 100, col = "red") #ligne verticale


par(mfrow = c(1, 2)) # configuration de la grille, 1 ligne et 2 colonnes<
# Histogramme
hist(BILL,
     xlab = "montant de la facture (en $)",
     ylab = "fréquence",
     main = "")
# Boîte à moustaches
with(donnees,
boxplot(BILL ~ factor(MONTH,
                      levels = substr(month.name, 1, 3)),
        main = "Facture d'électricité en fonction du mois",
        ylab = "facture d'électricité (en $)",
        xlab = "mois")
)
par(mfrow = c(1, 1)) # rétablir les graphiques


 # créer un dossier pour stocker le graphique
dir.create(path = "figures", showWarnings = FALSE)
# enregistrer au format pdf au format 8 po par 4 po
pdf("figures/mongraphique.pdf", width = 8, height = 4)
plot(BILL ~ CONSUMPTION, data = donnees)
dev.off() # fermer la console graphique

