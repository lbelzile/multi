## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(tidyverse,verbose=FALSE)


## ------------------------------------------------------------------------
# ceci est un commentaire
a = 1 # ceci est un commentaire mais a=1 est une commande R


## ------------------------------------------------------------------------
# Attention: changez le chemin d'acces pour l'adapter à votre cas
setwd("~/OneDrive - HEC Montréal/Documents/Cours_HEC/60-603/Course_notes/Seance2_R")


## ------------------------------------------------------------------------
2+3
pi
2+3*pi
log(2+3*pi)
log(2,base=10)
log(2,base=2)
exp(2.435785)


## ------------------------------------------------------------------------
a=3 # Crée une variable scalaire appelée a, qui prend la valeur 3
a # Affiche la valeur de  a
a<-3 # meme code avec l'opérateur <-
  a
b=5 # Crée une variable scalaire appelée b, qui prend la valeur 5
b # Affiche la valeur de  b
b-a # Affiche la valeur de  b-a
d=b/a # Stocke la valeur de b/a dans une nouvelle variable appelée d
d #  Affiche la valeur de d


## ------------------------------------------------------------------------
x=c(2,3,1,5,4,6,5,7,6,8) # Créé un vecteur x de 10 éléments numériques
x # Affiche les valeurs de x
x[3] # Affiche le 3eme élément de x
a=x[3] # Sauvegarde le 3eme élément de x dans un objet appelé a
a # Affiche la valeur de a


## ------------------------------------------------------------------------
salaire=c(36,54,42,81) # Salaire pour 4 employés 
augmentation=c(0.02,0.02,0.03,0.05) # Augmentation de salaire pour chaque employé
salaire_final=salaire*(1+augmentation)
salaire_final


## ------------------------------------------------------------------------
z=matrix(c(1,2,3,4,5,6,7,8,9), nrow=3, byrow=T) # Remplit la matrice par lignes
z
z.transpose=matrix(c(1,2,3,4,5,6,7,8,9), nrow=3, byrow=F) # Remplit la matrice par colonnes
z.transpose


## ------------------------------------------------------------------------
z[2,3] # Element de la ligne 2 et colonne 3
z[,1] # 1ere colonne
z[1,] # 1ere ligne


## ------------------------------------------------------------------------
z=matrix(0, nrow=5, ncol=2) # Remplit la matrice initialement avec des 0
# Creer 2 vecteurs
amount.dollars=c(55,70,100,20,15)
amount.euros=0.66*amount.dollars
# Remplir les 2 colonnes de la matrice avec chacun des vecteurs
z[,1]=amount.dollars
z[,2]=amount.euros

z


## ----eval=FALSE----------------------------------------------------------
## read.table(file, header = FALSE, sep = "",dec = ".", row.names, col.names,na.strings = "NA",skip = 0)


## ----eval=FALSE----------------------------------------------------------
## read.table("Data/electricbill.txt", header=TRUE)


## ------------------------------------------------------------------------
# Sauvegarde le contenu de la commande read.table dans un objet appelé "mydata" (vous pouvez donner le nom que vous voulez)
mydata=read.table("Data/electricbill.txt", header=TRUE)


## ----eval=FALSE----------------------------------------------------------
## mydata


## ------------------------------------------------------------------------
str(mydata)
head(mydata)


## ------------------------------------------------------------------------
nrow(mydata)
ncol(mydata)


## ------------------------------------------------------------------------
# Affiche l'element [2,3] (ligne #2 et col #3) du dataframe
mydata[2,3]
# Affiche la 1ere ligne
mydata[1,]
# Affiche la 3eme colonne (les 6 premiers éléments seulement)
head(mydata[,3])


## ------------------------------------------------------------------------
# 2eme colonne (YEAR)
head(mydata$YEAR)


## ------------------------------------------------------------------------
# Sauvegarder la 5eme colonne de mydata dans l'objet appelé toto
toto=mydata[,5]
# Affiche le contenu de toto (6 premiers elements)
head(toto)


## ------------------------------------------------------------------------
attach(mydata)
head(YEAR)


## ------------------------------------------------------------------------
# Créer une nouvelle variable YEAR2 qui compte les années de YEAR de 1 à 10
YEAR2=YEAR-1990
head(YEAR2)

# Convertir la temperature des Fahrenheit en Celsius
TEMP.CELSIUS=(TEMP-32)/1.8
head(TEMP.CELSIUS)


## ------------------------------------------------------------------------
# Creer un dataframe appelé mydata qui contient seulement 
# les colonnes YEAR, BILL and CONSUMPTION
mydata2=data.frame(YEAR=mydata$YEAR, BILL=mydata$BILL, CONSUMPTION=mydata$CONSUMPTION)
head(mydata2)
                           
# Modifie le dataframe existant mydata et y ajoute la  colonne 
# TEMP.CELSIUS créée plus haut
mydata=data.frame(mydata,TEMP.CELSIUS=TEMP.CELSIUS)
head(mydata)


## ------------------------------------------------------------------------
sex=c("male", "female", "female", "male", "male", "female", "female")
sex
smoking=c("yes", "no", "no", "yes", "no", "yes", "no", "no", "yes", "no")
smoking


## ------------------------------------------------------------------------
sex.factor=as.factor(sex)
sex.factor


## ------------------------------------------------------------------------
ls()


## ------------------------------------------------------------------------
rm(a)
ls()


## ----eval=FALSE----------------------------------------------------------
## # Installer les librairies
## install.packages("knitr")
## install.packages("rmarkdown")
## install.packages("markdown")
## 
## # Charger les libriries dans R
## library(knitr)
## library(rmarkdown)
## library(markdown)

