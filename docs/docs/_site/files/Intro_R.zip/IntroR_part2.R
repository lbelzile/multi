## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(tidyverse,verbose=FALSE)


## ------------------------------------------------------------------------
# Lecture des données
mydata=read.table("Data/electricbill.txt", header=TRUE)
mydata2=data.frame(YEAR=mydata$YEAR, MONTH=mydata$MONTH, 
                   BILL=mydata$BILL, CONSUMPTION=mydata$CONSUMPTION)
attach(mydata2)

length(BILL)
sum(BILL)
sum(BILL^2)
mean(BILL)
var(BILL)
sd(BILL)
sqrt(var(BILL))
summary(BILL)
summary(BILL^2)
quantile(BILL,0.25)
table(YEAR)


## ------------------------------------------------------------------------
summary(mydata2)
nrow(mydata2)
ncol(mydata2)
dim(mydata2)


## ------------------------------------------------------------------------
library(MASS)
x=mvrnorm(100,mu=1,Sigma=1)


## ------------------------------------------------------------------------
condition=(YEAR==1991)
condition


## ------------------------------------------------------------------------
condition=(YEAR>1995) # plus grand
condition=(YEAR>=1995) # plus grand ou égal
condition=(YEAR!=1992) # différent de...


## ------------------------------------------------------------------------
# Extrait de la variable YEAR seulement les éléments pour lesquelles la condition est vraie
condition=(YEAR>1995)
YEAR[condition]

# Code équivalent (et plus direct)
YEAR[YEAR>1995]

# Extrait de la variable BILL seulement les éléments correspondant à l'année 1991
BILL[YEAR==1991]


## ------------------------------------------------------------------------
# Extrait des données mydata2 les lignes correspondant à l'année 1991
mydata2[YEAR==1991,]

# Extrait des données mydata2 les observations avec BILL>200
mydata2[BILL>200,]


## ------------------------------------------------------------------------
# Créer un nouveau dataframe qui contient seulement les mois de janvier et fevrier
mydata4=mydata[(MONTH=='Jan' |MONTH=='Feb') ,] 
dim(mydata4)
head(mydata4)

# Créer un nouveau dataframe qui contient seulement les observations avec 100<BILL<200
mydata4=mydata[(BILL>100  & BILL<200) ,] 
dim(mydata4)
head(mydata4)


## ------------------------------------------------------------------------
# Sequence de 1 à 10
z=1:10
z

# Sequence de 5 à 10
z=5:10
z

# Sequence de 1 à 10 avec ses sauts de 2
w=seq(from=1,to=10,by=2)
w

# Sequence de 0 à 10, de longueur 11
w=seq(0,10,length=11)
w

# Repetition du chiffre 1, 10 fois
w=rep(1,10)
w

# Repetition de la séquence 1-2-3, 5 fois
w=rep(1:3,5)
w

# Repetition d'une séquence plus spécifique, 2 fois
w=rep(seq(from=1,to=10,by=2),2)
w


## ------------------------------------------------------------------------
# Extrait de BILL les observation (1,3,6)
BILL[c(1,3,6)]

# Extrait les 10 premières observations de BILL
BILL[1:10]

# Extrait les 10 premières lignes de mydata
mydata2[1:10,]

# Extrait une ligne sur deux de mydata2 pour les colonnes (1,2,4)
mydata2[seq(1,nrow(mydata),by=2),c(1,2,4)]


## ------------------------------------------------------------------------
plot(mydata$BILL,mydata$CONSUMPTION) 


## ------------------------------------------------------------------------
plot(mydata$BILL,mydata$CONSUMPTION, main="Scatter plot of bill vs consumption",
     xlab="Bill", ylab="Consumption")


## ------------------------------------------------------------------------
plot(mydata$BILL,mydata$CONSUMPTION, main="Scatter plot of bill vs consumption",
     xlab="Bill", ylab="Consumption",pch=21, bg="red")


## ------------------------------------------------------------------------
plot(mydata$BILL,mydata$CONSUMPTION, main="Scatter plot of bill vs consumption",
        xlab="Bill", ylab="Consumption")
regress=lm(mydata$CONSUMPTION~mydata$BILL)
abline (regress)
abline(h=6000, col="green")
abline(v=100, col="red")


## ------------------------------------------------------------------------
plot(mydata$NUM,mydata$BILL,type="l",xlab="Temps",ylab="Bill")


## ------------------------------------------------------------------------
hist(mydata$BILL, main = "Bill", xlab = "Range", ylab="Frequency")


## ------------------------------------------------------------------------
# Diagrammes simples
boxplot(mydata$BILL,main="Bill")

# Diagrammes cote à cote
boxplot(mydata$BILL~mydata$MONTH,main="Bill")


## ------------------------------------------------------------------------
par(mfrow=c(1,2))
plot(mydata$BILL,mydata$CONSUMPTION,xlab="Bill", ylab="Consumption")
plot(mydata$TEMP,mydata$CONSUMPTION,xlab="Bill", ylab="Consumption")
par(mfrow=c(1,1))


## ------------------------------------------------------------------------
jpeg("myplot.jpg")
plot(mydata$BILL,mydata$CONSUMPTION)
dev.off()


## ------------------------------------------------------------------------
pdf("myplots.pdf")
# Premiere page du fichier pdf
plot(mydata$BILL,mydata$CONSUMPTION)
# Seconde page du fichier pdf
plot(mydata$TEMP,mydata$CONSUMPTION)
# Fermer le fichier
dev.off()

