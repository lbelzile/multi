## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(tidyverse,verbose=FALSE)


## ------------------------------------------------------------------------
add.2.numbers = function(a,b)
{
   sum = a+b
   return(sum)
}
add.2.numbers(3,4)

#Autre façon équivalente d'appeler la fonction :
a=3
b=4
add.2.numbers(a,b)


## ------------------------------------------------------------------------
myfunction = function(a,b)
{
   sum = a+b
   diff=a-b
   return(list("mysum"=sum,"mydiff"=diff))
}
myfunction(3,4)


## ------------------------------------------------------------------------
# Afficher une série de chiffres successifs à l'écran
for (i in 1:10) 
{
   print(i^2) 
}

# Autre exemple
# Afficher une série d'éléments d'un ensemble donné à l'écran
for (w in c("red", "blue", "green")) 
{
   print(w) 
}


## ------------------------------------------------------------------------
# Remplir un objet x de facon iterative
x=NULL 
for(i in 1:10)
{
  x=c(x,i)
}
x  


## ------------------------------------------------------------------------
sales=function(x,emp)
{ 
# x : dataset 
# emp : ID de l'employé que l'on veut analyser 
# output : graphique 
   if(sum(x$EmpID==emp)==0) stop("This employee does not exist.") 
   par(mfrow=c(1,2)) 
   plot(1:12,x$nSales[x$EmpID==emp],type='l',xlab="Month", 
        ylab="Number of transactions") 
   title(paste("Number of transactions of employee",emp,"by month")) 
   plot(1:12,(x$TotSales/x$nSales)[x$EmpID==emp],type='l',
        xlab="Month", ylab="Average sale") 
   title("Average amount of a sale per month") 
}


## ------------------------------------------------------------------------
# Creation d'un vecteur qui contient une valeur NA
x=c(1,NA,5.6,-1,0) 

# Retourne des indicateurs de valeurs manquantes TRUE/FALSE
is.na(x) 

# Que se passe-t-il lorsque on veut prendre le log d'une valeur NA ?
y=log(x) 
y

# Retourne des indicateurs de valeurs manquantes"not a number" (NaN) TRUE/FALSE
is.na(y) 
is.nan(y) 
is.finite(y)


## ------------------------------------------------------------------------
mean(x) 
mean(x,na.rm=TRUE)


## ------------------------------------------------------------------------
sum(is.na(x)) # Number of missing values 
x[!is.na(x)]


## ------------------------------------------------------------------------
nb.na=function(x,p=.1)
{ 
  # x : un vecteur 
  # p : proportion de valeurs manquantes acceptable 
  # output : nombre de valeurs manquantes 
  
  if(mean(is.na(x))>=p) {warning("There are too many missing values.")} 
  return(sum(is.na(x)))
}


## ------------------------------------------------------------------------
mydata=read.table("Data/salesmen.txt",header=T)

# Mettre les données sous la forme d'un array
# Dimensions: 12 (mois) * 150 (clients) * 4 (variables)
mydata_array=array(as.matrix(mydata),c(12,150,4)) 

# Données pour le 1er client, 1er mois
mydata_array[1,1,]

# Données pour le 1er client
mydata_array[,1,]

# Données pour le 1er mois
head(mydata_array[1,,])

# Nombre de ventes pour tous les employes en janvier (6 premieres lignes)
head(mydata_array[1,,c(1,3)])

# Vente moyenne mensuelle pour le 3eme employé
mydata_array[,3,4]/mydata_array[,3,3] 


## ------------------------------------------------------------------------
mydata=read.table("Data/salesmen.txt",header=T)

# Creation d'une liste qui va contenir 5 elements:
# year, succursale, ID, nbre de ventes par mois et total vente par mois
mydata_list=list(year=2012, succ="Montreal Centre", ID=unique(mydata$EmpID), 
                 nb=t(matrix(mydata$nSales,nrow=12)), 
                 amount=t(matrix(mydata$TotSales,nrow=12)) )
names(mydata_list) 


## ------------------------------------------------------------------------
# Extraire de la liste le nbre de vente pour tous les employés par mois 
# (6 premières lignes)
head(mydata_list$nb) 

# Autre facon de faire la meme chose...
head(mydata_list[[4]])

# Extraire de la liste le nbre de vente pour tous les mois, premier sujet
mydata_list[[4]][1,]


## ------------------------------------------------------------------------
# Lignes = mois
# Colonnes = employés
nb_vente=mydata_array[,,3] 
dim(nb_vente)


## ------------------------------------------------------------------------
# Applique la fonction "mean" à toutes les lignes (donc mois) de la matrice
# Cela donne la moyenne des ventes par mois
apply(nb_vente,1,mean) 

# Meme chose, en spécifiant l'option na.rm=T de la fonction mean
apply(nb_vente,1,mean,na.rm=T)

# Applique la fonction "mean" à toutes les colonnes (donc employés) de la matrice
# Cela donne la moyenne des ventes par employé (6 premieres lignes)
head(apply(nb_vente,2,mean,na.rm=T))

# Valeurs min et max par mois
apply(nb_vente,1,range,na.rm=T)

# Valeurs min et max par employé pour les 10 premiers employés
apply(nb_vente[,1:10],2,range,na.rm=T)


## ------------------------------------------------------------------------
fn=function(i)
{
     sum((1:10)^i)
} 
sapply(0:5,fn)


## ------------------------------------------------------------------------
tapply(mydata$nSales,as.factor(mydata$EmpID),sum)

